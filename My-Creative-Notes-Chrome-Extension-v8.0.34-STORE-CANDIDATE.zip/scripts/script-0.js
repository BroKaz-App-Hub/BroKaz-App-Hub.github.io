
/* My Creative Notes Website v3. */
window.__mcgFlush=async function(){};
