
/* v13 rich text is stored in the existing note body field; no server or storage migration. */
const MCN_RICH_PREFIX='MCN13RICH:';
const MCN_ALLOWED=new Set(['B','STRONG','I','EM','SPAN','FONT','BR','DIV','P','UL','OL','LI']);
function mcnSanitize(html){
 const tpl=document.createElement('template');tpl.innerHTML=String(html||'');
 function clean(n){
  if(n.nodeType===Node.TEXT_NODE)return document.createTextNode(n.nodeValue);
  if(n.nodeType!==Node.ELEMENT_NODE)return document.createDocumentFragment();
  const tag=n.tagName.toUpperCase();
  if(['SCRIPT','STYLE','IFRAME','OBJECT','IMG','SVG','VIDEO','AUDIO'].includes(tag))return document.createDocumentFragment();
  const target=MCN_ALLOWED.has(tag)?document.createElement(tag==='FONT'?'span':tag.toLowerCase()):document.createDocumentFragment();
  if(tag==='SPAN'||tag==='FONT'){
    const color=tag==='FONT'?n.getAttribute('color'):(n.style&&n.style.color);
    if(color && /^(#[0-9a-fA-F]{3,8}|rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\))$/.test(color.trim())) target.style.color=color.trim();
  }
  for(const child of Array.from(n.childNodes))target.appendChild(clean(child));
  return target;
 }
 const out=document.createElement('div');for(const n of Array.from(tpl.content.childNodes))out.appendChild(clean(n));return out.innerHTML;
}
function mcnEditorHtml(body){return typeof body==='string'&&body.startsWith(MCN_RICH_PREFIX)?mcnSanitize(body.slice(MCN_RICH_PREFIX.length)):escapeHtml(body||'').replace(/\r\n?/g,'\n').replace(/\n/g,'<br>')}
function mcnNoteBodyForSave(editor){
 const rich=mcnSanitize(editor.innerHTML);
 const tmp=document.createElement('div');tmp.innerHTML=rich;
 // Read from the *visible* editor. Detached elements' innerText acts like
 // textContent in Chromium and silently drops all paragraph / line breaks.
 if(!tmp.querySelector('b,strong,i,em,span,ul,ol,li'))return editor.innerText||editor.textContent||'';
 return MCN_RICH_PREFIX+rich;
}
function mcnPlainText(body){
 if(typeof body==='string'&&body.startsWith(MCN_RICH_PREFIX)){
  const d=document.createElement('div');d.innerHTML=mcnSanitize(body.slice(MCN_RICH_PREFIX.length));
  // The conversion element must be attached for innerText to include <br>, lists and paragraphs.
  d.style.cssText='position:absolute;left:-100000px;top:0;white-space:pre-wrap;pointer-events:none;';
  document.body.appendChild(d);
  try{return d.innerText||d.textContent||'';}finally{d.remove()}
 }
 return body||'';
}
let mcnLastRange=null;
function mcnRememberSelection(){
 const a=el('cbody'),sel=window.getSelection();if(!a||!sel||!sel.rangeCount)return;
 const range=sel.getRangeAt(0);if(a.contains(range.commonAncestorContainer))mcnLastRange=range.cloneRange();
}
function mcnRestoreSelection(){
 const a=el('cbody');if(!a)return;
 const selection=window.getSelection();
 if(mcnLastRange&&a.contains(mcnLastRange.commonAncestorContainer)){
  selection.removeAllRanges();selection.addRange(mcnLastRange.cloneRange());
 } else {a.focus();const r=document.createRange();r.selectNodeContents(a);r.collapse(false);selection.removeAllRanges();selection.addRange(r)}
 a.focus();
}
function mcnSelectionOffset(root){
 const sel=window.getSelection();if(!sel||!sel.rangeCount||!root.contains(sel.anchorNode))return 0;
 const before=document.createRange();before.selectNodeContents(root);before.setEnd(sel.anchorNode,sel.anchorOffset);return before.toString().length;
}
function mcnPlaceCursor(root,pos){
 root.focus();const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),range=document.createRange();let current,offset=Math.max(0,pos||0),last=null;
 while(current=walker.nextNode()){last=current;if(offset<=current.nodeValue.length){range.setStart(current,offset);range.collapse(true);break}offset-=current.nodeValue.length}
 if(!current){if(last){range.setStart(last,last.nodeValue.length)}else{range.selectNodeContents(root);range.collapse(false)}}
 const sel=window.getSelection();sel.removeAllRanges();sel.addRange(range);mcnRememberSelection();
}
function mcnUpdateButtons(){
 const a=el('cbody');if(!a)return;
 const sel=window.getSelection(),inEditor=sel&&sel.rangeCount&&a.contains(sel.getRangeAt(0).commonAncestorContainer);
 for(const [id,cmd] of [['mcnBoldBtn','bold'],['mcnItalicBtn','italic']]){
  const b=el(id);if(!b)continue;
  let active=false;try{active=!!inEditor&&document.queryCommandState(cmd)}catch(e){}
  b.setAttribute('aria-pressed',active?'true':'false');
 }
}
function mcnApplyFormat(cmd,value){
 const a=el('cbody');if(!a)return;beforeNoteAction();mcnRestoreSelection();
 document.execCommand(cmd,false,value||null);mcnRememberSelection();afterNoteAction();mcnUpdateButtons();
}
function mcnTogglePalette(){
 mcnRememberSelection();const p=el('mcnColorPalette'),b=el('mcnFontColorBtn');p.classList.toggle('hidden');b.setAttribute('aria-expanded',p.classList.contains('hidden')?'false':'true');
}
function mcnSetColor(color){
 mcnApplyFormat('foreColor',color);
 const b=el('mcnFontColorBtn');b.querySelector('span').style.borderBottomColor=color;b.setAttribute('aria-expanded','false');
 el('mcnColorPalette').classList.add('hidden');
}
document.addEventListener('selectionchange',()=>{mcnRememberSelection();mcnUpdateButtons()});
document.addEventListener('paste',e=>{
 if(e.target?.id!=='cbody')return;
 e.preventDefault();const text=e.clipboardData?.getData('text/plain')||'';
 document.execCommand('insertText',false,text);
});
document.addEventListener('drop',e=>{if(e.target?.id==='cbody'&&e.dataTransfer?.files?.length)e.preventDefault()});
