MY CREATIVE NOTES — CHROME EXTENSION STORE CANDIDATE v8.0.34
Original books icon · 15 colour themes · Manifest V3 · no permissions

This is a release CANDIDATE for user testing, not yet a published product.
It adds a privacy policy link and local-storage notice to Settings; the
tested tab double-click fix, notes, tabs, theme controls and icons remain.

UPDATE TEST INSTALLATION WITHOUT LOSING NOTES
1. Export My Notes as a backup in your CURRENT extension.
2. Extract this ZIP and copy ALL files into your existing extension folder,
   replacing the prior files in that SAME folder.
3. Open chrome://extensions and click Reload below My Creative Notes.
4. Check a newly created tab opens Edit Tab when double-clicked; also
   test notes, themes, backup export/import and the Privacy link.
5. Keep your backup and do NOT uninstall the old extension without one.

STORE PUBLISHING
Upload this ZIP in Chrome Web Store Developer Dashboard ONLY after
your final review of listing, screenshot, privacy policy and functionality.
The ZIP contains the manifest.json at the root level.
Store screenshots and listing drafts are separate from this ZIP.
Do not claim it is live in Chrome Web Store until Google approves it.

Privacy policy:
https://brokaz-app-hub.github.io/creative-notes/extension-privacy.html

Notes are stored locally in each Chrome profile, not synced automatically.
