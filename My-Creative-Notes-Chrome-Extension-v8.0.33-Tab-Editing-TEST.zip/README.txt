MY CREATIVE NOTES — CHROME EXTENSION TEST v8.0.33
TAB EDITING FIX · ORIGINAL COLOURFUL BOOKS ICON

FIXED: Double-click the tab you just created to open Edit Tab.
This also works when selecting and editing a different tab.
Changing selected tabs no longer recreates their button during a click.

All 15 colour themes, notes, existing storage keys, import/export and
the original colourful books icon are preserved. Website unchanged.

SAFE UPDATE FROM YOUR EXISTING EXTENSION
1. Export a backup from Settings in your existing extension first.
2. Download and extract this ZIP.
3. Copy these files INTO THE SAME extension folder you installed before,
   replacing the previous files. Do not remove/uninstall the extension.
4. Open chrome://extensions and click RELOAD on My Creative Notes.
5. Create a new tab and immediately double-click it.
6. Try double-clicking an existing tab too. Test your notes are still there.

NEW INSTALL
Extract the ZIP, open chrome://extensions, turn Developer mode on,
click Load unpacked and choose the extracted folder.
Click/pin the My Creative Notes toolbar icon to open the app.

Your website data is stored separately from extension data: use
Export My Notes / Import My Notes to transfer between installations.
Do not remove this extension before exporting a backup.
This remains a private test build, not a Chrome Web Store release.
