MY CREATIVE NOTES — CHROME EXTENSION, ORIGINAL BOOKS ICON
TEST BUILD v8.0.32

This replaces the temporary CN icon with the original books icon already
used on the My Creative Notes website. All app functions and data storage
are unchanged. This is an unpublished test build.

UPDATE YOUR CURRENT TEST INSTALLATION SAFELY
1. In your current extension, use Settings > Export My Notes as a backup.
2. Extract this ZIP and copy its files into the SAME existing extension
   folder, replacing old files (do not delete the Chrome extension first).
3. Open chrome://extensions and click the Reload (round arrow) button
   under My Creative Notes. The original book icon should now appear.
4. Test the notes, tabs, themes and import/export again.
5. If Chrome does not refresh the icon immediately, close and reopen Chrome.

For a new installation: turn on Developer mode at chrome://extensions,
choose Load unpacked, and select the extracted extension folder.

Keep the folder in the same location. Each Chrome profile saves notes
locally. The extension and the website have separate storage, so use
Export My Notes / Import My Notes to transfer your notes between them.
Do not remove the extension without exporting a backup first.

Only the three PNG icon assets and these instructions differ from
the preceding v8.0.32 test archive. Website unchanged.
Not yet published in the Chrome Web Store.
