

// v11: stored theme choice is independent of notes and does not change any v10 keys.
const MCN_THEME_KEY='mcn-web-theme-v1';
const MCN_THEME_NAMES=['default','blue','teal','pink','orange','purple','sky-blue','slate-grey','charcoal-grey','forest-green','sage-green','burgundy','midnight-navy','chocolate-brown','golden-sand'];
let mcnCurrentTheme='default';
try { const oldTheme=localStorage.getItem(MCN_THEME_KEY); if(MCN_THEME_NAMES.includes(oldTheme))mcnCurrentTheme=oldTheme; } catch(e) {}
function applyMcnTheme(theme){
 if(!MCN_THEME_NAMES.includes(theme))theme='default';
 mcnCurrentTheme=theme;
 document.documentElement.setAttribute('data-mcn-theme',theme);
 document.querySelectorAll('#mcnThemePicker [data-theme-choice]').forEach(btn=>{
  btn.setAttribute('aria-pressed',String(btn.dataset.themeChoice===theme));
 });
}
function chooseMcnTheme(theme){
 if(!MCN_THEME_NAMES.includes(theme))return;
 applyMcnTheme(theme);
 try{localStorage.setItem(MCN_THEME_KEY,theme)}catch(e){console.warn('Theme preference was not saved',e)}
}
applyMcnTheme(mcnCurrentTheme);
const DEFAULT_DATA = [];
const GUIDE_OWNER_KEY='mcn-web-owner-v1';
let guideOwner='';
try{guideOwner=(localStorage.getItem(GUIDE_OWNER_KEY)||'').trim().slice(0,16)}catch(e){}
function guideName(){return guideOwner?guideOwner.replace(/[’']s$/i,'')+"'s Creative Notes":'My Creative Notes'}
function applyGuideBrand(){
 const title=guideName();
 document.title=title;
 const ownerText=guideOwner?guideOwner.replace(/[’']s$/i,'')+"'s":'My';
 const ownerEl=document.getElementById('guideBrandOwner');
 const brandRow=document.getElementById('guideBrandName');
 if(ownerEl){ownerEl.textContent=ownerText;ownerEl.title=title;ownerEl.style.fontSize='29px';for(let size=29;ownerEl.scrollWidth>ownerEl.clientWidth && size>=15;size--)ownerEl.style.fontSize=size+'px';}
 if(brandRow)brandRow.title=title;
 const welcome=document.getElementById('guideWelcomeTitle');
 if(welcome)welcome.textContent='Welcome to '+title;
 const preview=document.getElementById('guideNamePreview');
 if(preview)preview.textContent='App name: '+title;
}
function saveGuideName(){
 const field=document.getElementById('guideOwnerName');if(!field)return;
 const name=field.value.trim().replace(/\s+/g,' ').slice(0,16);
 try{if(name)localStorage.setItem(GUIDE_OWNER_KEY,name);else localStorage.removeItem(GUIDE_OWNER_KEY)}
 catch(e){alert('Could not save your name in this browser.');return}
 guideOwner=name;applyGuideBrand();closeSettings();toast('Guide name saved');nextTourStep(1,2);
}
// Browser preview: do not access any other guide's stored notes.
// A shareable blank HTML file contains zero notes; each friend uses their own browser storage.
const KEY='mcn-web-notes-v1';
const TAB_KEY='mcn-web-tabs-v1';
let sections=[],tabs=[];
let webStorageReadError=false;
try {const stored=localStorage.getItem(KEY);if(stored!==null){const parsed=JSON.parse(stored);if(!Array.isArray(parsed))throw Error('Invalid stored notes');sections=parsed;}}catch(e){sections=[];webStorageReadError=true;}
try {const stored=localStorage.getItem(TAB_KEY);if(stored!==null){const parsed=JSON.parse(stored);if(!Array.isArray(parsed))throw Error('Invalid stored tabs');tabs=parsed;}}catch(e){tabs=[];webStorageReadError=true;}
function webGuardSave(){if(webStorageReadError)throw Error('Previously saved notes could not be read. Saving is blocked to protect them. Use Restore Backup after checking your backup file.');}
if(webStorageReadError){window.addEventListener('DOMContentLoaded',()=>{
  const warning=document.createElement('div');warning.setAttribute('role','alert');warning.className='mcnDataWarning';warning.textContent='Saved notes could not be loaded. Saving is blocked to protect your existing data. Restore a known-good backup before editing.';
  document.body.prepend(warning);
});}
function defaultTab(s){return 'work'}
for(const s of sections){if(!s.tab||!tabs.some(t=>t.id===s.tab))s.tab=defaultTab(s)}
// Remember where each app window is, even if Chrome refreshes its page after an update.
// Only these two navigation identifiers are kept in this tab's sessionStorage;
// the notes, sections and tabs are stored in this browser.
const MCN_NAV_KEY='mcn-web-navigation-v1';
function readNav(){
 try{const value=JSON.parse(sessionStorage.getItem(MCN_NAV_KEY)||'null');return value&&typeof value==='object'?value:null}
 catch(e){return null}
}
function saveNav(){
 try{sessionStorage.setItem(MCN_NAV_KEY,JSON.stringify({tab:activeTab,section:selected}))}
 catch(e){}
}
const previousNav=readNav();
let activeTab=(previousNav&&tabs.some(t=>t.id===previousNav.tab)?previousNav.tab:tabs[0]?.id)||'home';
let selected=(previousNav&&sections.some(s=>s.id===previousNav.section&&s.tab===activeTab)?previousNav.section:sections.find(s=>s.tab===activeTab)?.id)||'home';
let editing=null,searchText='';
function saveTabs(){try{webGuardSave();localStorage.setItem(TAB_KEY,JSON.stringify(tabs));recordHistory()}catch(e){alert(e.message)}}
// Older Guides put the emoji at the start of the name. Display it separately
// without modifying existing stored tab data until that tab is edited.
function tabParts(t){
 const name=String(t.name||'');
 const match=name.match(/^(\S+)\s+(.+)$/u);
 const legacyIcon=match && /[\p{Extended_Pictographic}\p{Regional_Indicator}]/u.test(match[1]) ? match[1] : '';
 return {icon:typeof t.icon==='string'?t.icon:legacyIcon,label:(legacyIcon?match[2]:name).trim()};
}
function renderTabs(){
 const host=el('tabs');
 const markup=tabs.map(t=>{
 const parts=tabParts(t);
 return `<button role="tab" draggable="true" data-tab-id="${t.id}" aria-selected="${t.id===activeTab}" class="tab ${t.id===activeTab?'active':''}" title="Click to open. Double-click to edit name and icon. Drag to reorder." data-mcn-click="switchTab('${t.id}')" data-mcn-dblclick="renameTab('${t.id}')" data-mcn-dragstart="startTabDrag(event,'${t.id}')" data-mcn-dragover="tabDragOver(event,'${t.id}')" data-mcn-dragleave="tabDragLeave(event)" data-mcn-drop="dropOnTab(event,'${t.id}')" data-mcn-dragend="finishDrag()">${parts.icon?`<span class="tabEmoji" aria-hidden="true">${escapeHtml(parts.icon)}</span>`:''}${escapeHtml(parts.label)}</button>`;
 }).join('')+`<button class="addtab" data-mcn-click="addTab()">＋ New Tab</button>`;
 // Keep the tab button mounted while the user clicks it twice.
 // Replacing it with innerHTML on the first click cancels native dblclick.
 const scratch=document.createElement('div');
 scratch.innerHTML=markup;
 const oldTabs=new Map(Array.from(host.children).filter(node=>node.dataset.tabId).map(node=>[node.dataset.tabId,node]));
 const oldAdd=Array.from(host.children).find(node=>node.classList.contains('addtab'));
 const desired=Array.from(scratch.children).map(node=>{
  const current=node.dataset.tabId?oldTabs.get(node.dataset.tabId):oldAdd;
  if(!current)return node;
  if(current.className!==node.className)current.className=node.className;
  const active=node.getAttribute('aria-selected');
  if(active!==null&&current.getAttribute('aria-selected')!==active)current.setAttribute('aria-selected',active);
  if(current.innerHTML!==node.innerHTML)current.innerHTML=node.innerHTML;
  return current;
 });
 desired.forEach((node,index)=>{if(host.children[index]!==node)host.insertBefore(node,host.children[index]||null)});
 while(host.children.length>desired.length)host.lastElementChild.remove();
}
let draggingItem=null;
function startTabDrag(event,id){draggingItem={type:'tab',id};event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain','tab:'+id);}
let suppressSidebarClickUntil=0;
function startSectionDrag(event,id){draggingItem={type:'section',id};suppressSidebarClickUntil=Date.now()+450;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain','section:'+id);}
function clickSidebar(event,id){
 // A mouse release after dragging a section is not a navigation request.
 if(Date.now()<suppressSidebarClickUntil){event.preventDefault();event.stopPropagation();return}
 const section=sections.find(s=>s.id===id);
 if(!section||section.tab!==activeTab)return;
 select(id);
}
function tabDragOver(event,id){if(!draggingItem||draggingItem.id===id&&draggingItem.type==='tab')return;event.preventDefault();event.dataTransfer.dropEffect='move';event.currentTarget.classList.add('dragTarget');}
function tabDragLeave(event){event.currentTarget.classList.remove('dragTarget')}
function dropOnTab(event,id){event.preventDefault();event.currentTarget.classList.remove('dragTarget');const source=draggingItem;draggingItem=null;if(!source)return;
 if(source.type==='tab'&&source.id!==id){const from=tabs.findIndex(t=>t.id===source.id),to=tabs.findIndex(t=>t.id===id);if(from<0||to<0)return;const [item]=tabs.splice(from,1);tabs.splice(to,0,item);saveTabs();renderTabs();toast('Tab order updated');}
 else if(source.type==='section'){const section=sections.find(s=>s.id===source.id);if(!section||section.tab===id)return;section.tab=id;save();switchTab(id);select(section.id);toast('Section moved to '+tabParts(tabs.find(t=>t.id===id)||{name:'Tab'}).label);}}
// v7: reorder sections within the current sidebar. The old drag-to-top-tab behaviour remains.
function sectionDragOver(event,id){
 if(!draggingItem||draggingItem.type!=='section'||draggingItem.id===id)return;
 const moving=sections.find(s=>s.id===draggingItem.id),target=sections.find(s=>s.id===id);
 if(!moving||!target||moving.tab!==target.tab)return;
 event.preventDefault();event.dataTransfer.dropEffect='move';
 const bounds=event.currentTarget.getBoundingClientRect();
 event.currentTarget.classList.remove('dragAbove','dragBelow');
 event.currentTarget.classList.add(event.clientY<bounds.top+bounds.height/2?'dragAbove':'dragBelow');
}
function sectionDragLeave(event){event.currentTarget.classList.remove('dragAbove','dragBelow')}
function dropOnSection(event,id){
 event.preventDefault();event.stopPropagation();
 const row=event.currentTarget;
 const after=row.classList.contains('dragBelow');
 row.classList.remove('dragAbove','dragBelow');
 const source=draggingItem;draggingItem=null;
 if(!source||source.type!=='section'||source.id===id)return;
 const from=sections.findIndex(s=>s.id===source.id),to=sections.findIndex(s=>s.id===id);
 if(from<0||to<0||sections[from].tab!==sections[to].tab)return;
 const [moved]=sections.splice(from,1);
 let place=sections.findIndex(s=>s.id===id);
 if(after)place++;
 sections.splice(place,0,moved);
 save();saveNav();renderNav();toast('Sidebar order saved');
}
function moveSectionWithKeyboard(event,id){
 if(!event.altKey||!['ArrowUp','ArrowDown'].includes(event.key))return;
 event.preventDefault();
 const tabSections=sections.filter(s=>s.tab===activeTab);
 const current=tabSections.findIndex(s=>s.id===id);
 const adjacent=tabSections[current+(event.key==='ArrowUp'?-1:1)];
 if(!adjacent)return;
 const a=sections.findIndex(s=>s.id===id),b=sections.findIndex(s=>s.id===adjacent.id);
 [sections[a],sections[b]]=[sections[b],sections[a]];
 save();saveNav();renderNav();
 const focus=Array.from(document.querySelectorAll('#nav .navbtn')).find(btn=>btn.dataset.sectionId===id);
 if(focus)focus.focus();
 toast('Sidebar order saved');
}
function finishDrag(){if(draggingItem?.type==='section')suppressSidebarClickUntil=Date.now()+250;draggingItem=null;document.querySelectorAll('.dragTarget,.dragAbove,.dragBelow').forEach(x=>x.classList.remove('dragTarget','dragAbove','dragBelow'))}
function switchTab(id){if(!tabs.some(t=>t.id===id))return;activeTab=id;selected=sections.find(s=>s.tab===id)?.id||'home';saveNav();editing=null;searchText='';el('search').value='';render();el('scrollArea').scrollTop=0}
// Name and icon selection are part of the same New/Edit Tab window.
let tabEditorId=null,tabEditorIcon='',tabEditorPreviousFocus=null;
function addTab(){openTabEditor()}
function renameTab(id){openTabEditor(id)}
function renameCurrentTab(){if(tabs.some(t=>t.id===activeTab))openTabEditor(activeTab)}
function openTabEditor(id=null){
 const tab=id===null?null:tabs.find(t=>t.id===id);
 if(id!==null&&!tab)return;
 tabEditorPreviousFocus=document.activeElement;
 tabEditorId=tab?tab.id:null;
 const parts=tab?tabParts(tab):{icon:'',label:''};
 tabEditorIcon=parts.icon;
 el('tabEditorTitle').textContent=tab?'Edit Tab':'New Tab';
 el('tabEditorSave').textContent=tab?'Save Changes':'Create Tab';
 el('tabEditorDelete').classList.toggle('hidden',!tab);
 el('tabEditorName').value=parts.label;
 el('tabEditorError').textContent='';
 el('tabEditorOverlay').classList.remove('hidden');
 renderTabEditorIcons();
 el('tabEditorName').focus();if(tab)el('tabEditorName').select();
}
function closeTabEditor(){
 el('tabEditorOverlay').classList.add('hidden');
 tabEditorId=null;
 const target=tabEditorPreviousFocus;tabEditorPreviousFocus=null;
 if(target?.isConnected)target.focus();
}
function deleteTabFromEditor(){
 const id=tabEditorId,tab=tabs.find(t=>t.id===id);
 if(!tab)return;
 const question='Delete the tab “'+tabParts(tab).label+'” and all its contents?';
 if(!confirm(question))return;
 const remainingTabs=tabs.filter(t=>t.id!==id);
 const remainingSections=sections.filter(s=>s.tab!==id);
 try{
  webGuardSave();
  localStorage.setItem(TAB_KEY,JSON.stringify(remainingTabs));
  localStorage.setItem(KEY,JSON.stringify(remainingSections));
 }catch(error){alert('Could not delete the tab safely: '+error.message);return}
 tabs=remainingTabs;sections=remainingSections;
 if(activeTab===id)activeTab=tabs[0]?.id||'home';
 if(!sections.some(s=>s.id===selected&&s.tab===activeTab))selected=sections.find(s=>s.tab===activeTab)?.id||'home';
 editing=null;draftNoteId=null;draftSectionId=null;searchText='';el('search').value='';
 recordHistory();saveNav();closeTabEditor();render();el('scrollArea').scrollTop=0;toast('Tab deleted');
}
function renderTabEditorIcons(){
 const icons=[],seen=new Set();
 for(const items of Object.values(ICON_GROUPS)){
  for(const icon of items.split(' ')){
   if(icon&&!seen.has(icon)){seen.add(icon);icons.push(icon)}
  }
 }
 // Preserve legacy custom emoji as selectable options, even if not in the standard list.
 if(tabEditorIcon&&!seen.has(tabEditorIcon))icons.unshift(tabEditorIcon);
 const blankOption=`<button type="button" class="tabEditorIconChoice tabEditorBlankChoice ${tabEditorIcon===''?'selected':''}" aria-label="No icon (blank)" aria-pressed="${tabEditorIcon===''}" title="No icon (default)" data-mcn-click="chooseTabEditorIcon('')">Blank</button>`;
 el('tabEditorIconGrid').innerHTML=blankOption+icons.map(icon=>`<button type="button" class="tabEditorIconChoice ${icon===tabEditorIcon?'selected':''}" aria-label="Choose ${escapeHtml(icon)} icon" aria-pressed="${icon===tabEditorIcon}" title="${escapeHtml(icon)}" data-mcn-click="chooseTabEditorIcon('${icon}')">${escapeHtml(icon)}</button>`).join('');
}
function chooseTabEditorIcon(icon){tabEditorIcon=icon;renderTabEditorIcons()}
function saveTabEditor(event){
 event.preventDefault();
 const name=el('tabEditorName').value.trim().replace(/\s+/g,' ').slice(0,60);
 const error=el('tabEditorError');error.textContent='';
 if(!name){error.textContent='Please give this tab a name.';el('tabEditorName').focus();return}
 if(tabs.some(t=>t.id!==tabEditorId&&tabParts(t).label.toLocaleLowerCase()===name.toLocaleLowerCase())){
  error.textContent='Another tab already has that name.';el('tabEditorName').focus();return;
 }
 const id=tabEditorId;
 if(id===null){
  const newId='t'+Date.now()+'n'+Math.floor(Math.random()*10000);
  tabs.push({id:newId,name,icon:tabEditorIcon});
  saveTabs();closeTabEditor();switchTab(newId);
  toast('New tab created');nextTourStep(2,3);
 }else{
  const tab=tabs.find(t=>t.id===id);if(!tab)return;
  const old=tabParts(tab);
  if(old.label===name&&old.icon===tabEditorIcon){closeTabEditor();return}
  tab.name=name;tab.icon=tabEditorIcon;
  saveTabs();closeTabEditor();render();toast('Tab updated');
 }
}
function tabNoteCount(id){return sections.filter(s=>s.tab===id).reduce((total,s)=>total+s.cards.length,0)}
function tabActionsHtml(sectionId){
 const addAction=sectionId?`addCard('${sectionId}')`:'addCard()';
 return `<div class="tools"><button id="${sectionId?'':'firstAddNoteBtn'}" class="btn" data-mcn-click="${addAction}">Add Note</button></div>`;
}
function moveSection(id){const s=sections.find(x=>x.id===id);if(!s)return;const names=tabs.map((t,i)=>`${i+1}. ${t.name}`).join('\n');const choice=prompt('Move this section to which tab? Enter the number:\n'+names);if(choice===null)return;const t=tabs[Number(choice)-1];if(!t){alert('Choose a valid tab number.');return}s.tab=t.id;save();switchTab(t.id);select(id)}
const el=id=>document.getElementById(id),escapeHtml=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// First-run walk-through. It never changes saved notes unless the user chooses to.
const TOUR_KEY='mcn-web-tour-v1';
let tourStep=-1, tourMarked=null;
const TOUR_STEPS=[
 {selector:'#settingsButton',counter:'Step 1 of 4',title:'Personalise your Guide',description:'Start by clicking the Settings gear. You can add your name to the app title.',hint:'Click Settings ⚙'},
 {selector:'#guideOwnerName',counter:'Step 1 of 4',title:'Enter your name',description:'Type your name, then click Save Name. The Guide heading will update automatically.',hint:'Type a name, then Save Name'},
 {selector:'.addtab',counter:'Step 2 of 4',title:'Make your first tab',description:'Click New Tab, then type a name for your topic, such as Recipes, Work or Personal.',hint:'Click New Tab'},
 {selector:'#firstAddNoteBtn',counter:'Step 3 of 4',title:'Add a note',description:'Your new tab is ready. Click Add Note to write your first note.',hint:'Click Add Note'},
 {selector:'#ctitle',counter:'Step 4 of 4',title:'Your first note!',description:'Give your note a heading, then add information underneath. When finished, click Save Changes. Your Guide is ready to use.',hint:'Save your note, or Finish'}
];
function startTutorial(){
 closeSettings();
 if(tourMarked)tourMarked.classList.remove('tourTarget');
 tourMarked=null;tourStep=0;
 renderTour();
}
function finishTutorial(){
 tourStep=-1;
 if(tourMarked){tourMarked.classList.remove('tourTarget');tourMarked=null}
 el('settingsWrap').classList.remove('tourContainer');
 el('tourWash').classList.add('hidden');
 el('tourPopover').classList.add('hidden');
 try{localStorage.setItem(TOUR_KEY,'completed')}catch(e){}
}
function nextTourStep(expected,next){if(tourStep===expected){tourStep=next;renderTour()}}
function renderTour(){
 if(tourStep<0)return;
 const step=TOUR_STEPS[tourStep];
 if(!step)return;
 if(tourMarked){tourMarked.classList.remove('tourTarget');tourMarked=null}
 el('settingsWrap').classList.toggle('tourContainer',tourStep<=1);
 const target=document.querySelector(step.selector);
 const pop=el('tourPopover');
 if(!target){pop.classList.add('hidden');el('tourWash').classList.add('hidden');return}
 tourMarked=target;target.classList.add('tourTarget');
 if(tourStep===2&&typeof target.scrollIntoView==='function')target.scrollIntoView({block:'nearest',inline:'nearest'});
 el('tourCounter').textContent=step.counter;
 el('tourTitle').textContent=step.title;
 el('tourDescription').textContent=step.description;
 el('tourHint').textContent=step.hint;
 el('tourSkip').textContent=tourStep===4?'Finish tutorial':'Skip tutorial';
 pop.classList.remove('hidden');el('tourWash').classList.remove('hidden');
 positionTour();
}
function positionTour(){
 if(tourStep<0||!tourMarked||!tourMarked.isConnected)return;
 const r=tourMarked.getBoundingClientRect(),pop=el('tourPopover');
 if(pop.classList.contains('hidden'))return;
 const w=pop.offsetWidth,h=pop.offsetHeight,vw=window.innerWidth,vh=window.innerHeight;
 // The name field sits in an open Settings menu: do not cover Save Name.
 if(tourStep===1){
  const menu=el('settingsMenu').getBoundingClientRect();
  if(menu.left>w+28){
   pop.style.left=Math.max(12,menu.left-w-14)+'px';
   pop.style.top=Math.max(12,Math.min(vh-h-12,menu.top+7))+'px';
   pop.dataset.placement='left';return;
  }
  if(menu.right+w+25<vw){
   pop.style.left=(menu.right+14)+'px';
   pop.style.top=Math.max(12,Math.min(vh-h-12,menu.top+7))+'px';
   pop.dataset.placement='right';return;
  }
  const top=menu.bottom+13+h<vh-9?menu.bottom+13:Math.max(12,menu.top-h-16);
  const below=top>menu.top;
  pop.style.left=Math.max(12,Math.min(vw-w-12,menu.left))+'px';
  pop.style.top=Math.max(12,Math.min(vh-h-12,top))+'px';
  pop.dataset.placement=below?'below':'above';
  pop.style.setProperty('--tourArrowLeft','30px');return;
 }
 const left=Math.max(12,Math.min(vw-w-12,r.left+r.width/2-w/2));
 const below=r.bottom+20+h<vh-10, above=r.top-20-h>10;
 const placement=below||!above?'below':'above';
 const top=placement==='below'?Math.min(vh-h-12,r.bottom+20):Math.max(12,r.top-h-20);
 pop.style.left=left+'px';pop.style.top=Math.max(12,top)+'px';
 pop.dataset.placement=placement;
 pop.style.setProperty('--tourArrowLeft',Math.max(18,Math.min(w-30,r.left+r.width/2-left-7))+'px');
}
window.addEventListener('resize',()=>{if(tourStep>=0)positionTour()});
el('scrollArea').addEventListener('scroll',()=>{if(tourStep>=0)positionTour()},{passive:true});
el('tabs').addEventListener('scroll',()=>{if(tourStep>=0)positionTour()},{passive:true});

// History snapshots cover saved notes, sections, tab changes and accidental deletions.
const undoStack=[],redoStack=[];let lastSnapshot=JSON.stringify({sections,tabs});
function recordHistory(){const next=JSON.stringify({sections,tabs});if(next!==lastSnapshot){undoStack.push(lastSnapshot);if(undoStack.length>60)undoStack.shift();redoStack.length=0;lastSnapshot=next}updateHistoryButtons()}
function updateHistoryButtons(){const u=document.getElementById('undoBtn'),r=document.getElementById('redoBtn');if(u)u.disabled=!undoStack.length;if(r)r.disabled=!redoStack.length}
function restoreSnapshot(snapshot){const state=JSON.parse(snapshot);sections=state.sections;tabs=state.tabs;lastSnapshot=snapshot;try{localStorage.setItem(KEY,JSON.stringify(sections));localStorage.setItem(TAB_KEY,JSON.stringify(tabs))}catch(e){alert('Could not save restored state: '+e.message)}if(!tabs.some(t=>t.id===activeTab))activeTab=tabs[0]?.id||'home';if(!sections.some(s=>s.id===selected&&s.tab===activeTab))selected='home';editing=null;searchText='';el('search').value='';saveNav();render();updateHistoryButtons()}
function undoChange(){if(!undoStack.length)return;redoStack.push(lastSnapshot);restoreSnapshot(undoStack.pop());toast('Previous change restored')}
function redoChange(){if(!redoStack.length)return;undoStack.push(lastSnapshot);restoreSnapshot(redoStack.pop());toast('Change reapplied')}
function save(){if(webStorageReadError){alert('Saving is blocked because saved notes could not be read. Restore a backup before editing.');return;}recordHistory();try{localStorage.setItem(KEY,JSON.stringify(sections))}catch(e){alert('Could not save. Please export a backup and check browser storage: '+e.message)}}
function toast(msg){el('toast').textContent=msg;el('toast').style.display='block';setTimeout(()=>el('toast').style.display='none',2300)}const MCN_SIDEBAR_KEY='mcn-web-sidebar-hidden-v8';
let mcnSidebarHidden=false;
try{mcnSidebarHidden=localStorage.getItem(MCN_SIDEBAR_KEY)==='1'}catch(e){}
function mcnSetSidebarHidden(hidden){
 mcnSidebarHidden=Boolean(hidden);
 document.querySelector('.shell').classList.toggle('mcnSidebarHidden',mcnSidebarHidden);
 el('sidebar').classList.toggle('open',!mcnSidebarHidden);
 const btn=el('sidebarReopen');
 if(btn){const opened=!mcnSidebarHidden;btn.setAttribute('aria-label',opened?'Hide sidebar':'Show sidebar');btn.title=opened?'Hide sidebar':'Show sidebar';btn.setAttribute('aria-expanded',String(opened));btn.textContent=opened?'☰':'☰'}
 try{localStorage.setItem(MCN_SIDEBAR_KEY,mcnSidebarHidden?'1':'0')}catch(e){}
}
function toggleSidebar(){mcnSetSidebarHidden(!mcnSidebarHidden)}
mcnSetSidebarHidden(mcnSidebarHidden);
function select(id){if(id!=='home'&&!sections.some(s=>s.id===id&&s.tab===activeTab))return;selected=id;saveNav();editing=null;searchText='';el('search').value='';render();el('scrollArea').scrollTop=0}function showHome(){select(sections.find(s=>s.tab===activeTab)?.id||'home')}
function renderNav(){el('nav').innerHTML=sections.filter(s=>s.tab===activeTab).map(s=>`<button draggable="true" data-section-id="${s.id}" title="Drag to reorder this section, or drag onto a top tab to move it. Alt+Up/Down to reorder." data-mcn-dragstart="startSectionDrag(event,'${s.id}')" data-mcn-dragover="sectionDragOver(event,'${s.id}')" data-mcn-dragleave="sectionDragLeave(event)" data-mcn-drop="dropOnSection(event,'${s.id}')" data-mcn-dragend="finishDrag()" data-mcn-keydown="moveSectionWithKeyboard(event,'${s.id}')" class="navbtn ${s.id===selected?'active':''}" data-mcn-click="clickSidebar(event,'${s.id}')"><span>${escapeHtml(s.icon)}</span><span>${escapeHtml(s.title)}</span></button>`).join('')||(tabs.length?'<p class="sub" style="padding:12px">No sidebar sections yet. Select Add Note to start.</p>':'<p class="sub" style="padding:12px">Create a new tab to begin.</p>')}
function renderBody(src){
 if(typeof src==='string'&&src.startsWith(MCN_RICH_PREFIX))return mcnSanitize(src.slice(MCN_RICH_PREFIX.length));
 const lines=src.split(/\r?\n/),out=[];let mode='',items=[];
 const flush=()=>{if(mode){out.push('<'+mode+'>'+items.map(x=>'<li>'+escapeHtml(x)+'</li>').join('')+'</'+mode+'>');mode='';items=[]}};
 for(const original of lines){const t=original.trim(),bullet=t.match(/^(?:[-*•])\s+(.+)$/),number=t.match(/^\d+[.)]\s+(.+)$/);
 if(bullet||number){const kind=bullet?'ul':'ol';if(mode&&mode!==kind)flush();mode=kind;items.push((bullet||number)[1]);continue}
 flush();if(!t){out.push('<div style="height:7px"></div>');continue}
 if(t.endsWith(':')&&t.length<100)out.push('<p class="noteLabel">'+escapeHtml(t)+'</p>');
 else out.push('<p>'+escapeHtml(t)+'</p>')
 }flush();return out.join('')
}
// Icon picker for both note text and section headings.
const ICON_GROUPS = {
'Work & contact':'💼 📇 📋 📞 ☎️ 📱 📧 ✉️ 📨 📬 📠 💻 🖥️ ⌨️ 🖨️ 📎 📌 📂 📁 🗂️ 📝 📑 📊 📈 📉 📆 📅 🗓️ ⏰ ⏱️ 🔔 ✅ ☑️ ❌ ⚠️ 🔄 🔁 🛠️ ⚙️ 🔍 🔒 🔑 🌐 🔗 📍 🏢 👥 🧑‍💻 🎯',
'Health & donation':'🩸 ❤️ 🫀 🩺 💊 💉 🩹 🧬 🧪 🩻 🏥 🚑 🧫 👨‍⚕️ 👩‍⚕️ 🧑‍⚕️ 🦷 🌡️ 💪 🧠 🫁 🦴 👶 🤒 🥼',
'Learning & spiritual':'📖 📚 📕 📗 📘 📙 📓 📔 🧾 ✏️ 🖊️ 🖋️ 🎓 🏫 🧑‍🏫 💡 🙏 🌿 🌱 🌳 🌺 🌸 🌏 🌊 🗣️ 💬 🎤 🎧 🔤 🇳🇿',
'Home & life':'🏠 🏡 🔧 🛒 🛍️ 💳 💰 🪙 🧮 🧹 🧺 🍽️ 🥗 ☕ 🐕 🐶 🐾 🚗 🚌 ✈️ 🎁 🏆 ⭐ 🌟 ✨ 🎨 🎵 🏃 🚶 ♟️ 🎮',
'Labels & status':'🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔺 🔹 🔸 💠 ➡️ ⬅️ ⬆️ ⬇️ ❗ ❓ ✔️ ❕ 💯 ➕ ➖ 🆕 🆗 🆒 🔥 🚀 😊 👍'
};
let iconPickerMode=null,iconPickerSection=null,iconCursor=null;
function openIconPicker(mode,id){
 iconPickerMode=mode;iconPickerSection=id||null;
 if(mode==='note')mcnRememberSelection();
 el('iconDialogTitle').textContent=mode==='section'?'Choose section icon':'Add an icon to your note';
 el('iconSearch').value='';el('iconOverlay').classList.remove('hidden');renderIconChoices();el('iconSearch').focus();
}
function renderIconChoices(){
 const query=el('iconSearch').value.trim().toLowerCase();let html='';
 for(const [category, icons] of Object.entries(ICON_GROUPS)){
  const words=icons.split(' ');
  if(query && !category.toLowerCase().includes(query)){
   // Basic useful keyword aliases for common icons.
   const aliases={phone:'📱 📞 ☎️',email:'📧 ✉️ 📨',heart:'❤️ 🫀',book:'📖 📚 📕 📗 📘',dog:'🐕 🐶 🐾',blood:'🩸 💉',star:'⭐ 🌟',check:'✅ ☑️ ✔️',folder:'📂 📁 🗂️',medical:'🩺 💊 💉 🏥',calendar:'📅 📆 🗓️',time:'⏰ ⏱️',money:'💰 💳 🪙',work:'💼 🏢 📋',home:'🏠 🏡',maori:'🌿 🌏 🇳🇿'};
   const matches=words.filter(x=>(aliases[query]||'').includes(x));if(!matches.length)continue;
   html+=matches.map(icon=>`<button type="button" class="iconChoice" title="${category}" data-mcn-click="chooseIcon('${icon}')">${icon}</button>`).join('');continue;
  }
  html+=words.map(icon=>`<button type="button" class="iconChoice" title="${category}" data-mcn-click="chooseIcon('${icon}')">${icon}</button>`).join('');
 }
 el('iconGrid').innerHTML=html||'<p class="muted">No matching icons. Try a different word.</p>';
}
function closeIconPicker(){el('iconOverlay').classList.add('hidden');iconPickerMode=null;iconPickerSection=null;iconCursor=null;}
function chooseIcon(icon){
 if(iconPickerMode==='section'){
  const s=sections.find(x=>x.id===iconPickerSection);if(s){s.icon=icon;save();closeIconPicker();render();toast('Section icon changed');}return;
 }
 const area=el('cbody');if(!area)return;
 beforeNoteAction();mcnRestoreSelection();document.execCommand('insertText',false,icon+' ');
 closeIconPicker();area.focus();afterNoteAction();
}
// Editor history is separate from saved app history, and works before Save Changes.
let notePast=[],noteFuture=[],noteCurrent=null,noteHistoryId=null;
function noteState(){
 const title=el('ctitle'),body=el('cbody');if(!title||!body)return null;
 const titleFocus=document.activeElement===title;
 return {title:title.value,body:mcnSanitize(body.innerHTML),focus:titleFocus?'ctitle':'cbody',start:titleFocus?title.selectionStart:mcnSelectionOffset(body),end:titleFocus?title.selectionEnd:mcnSelectionOffset(body)};
}
function noteEqual(a,b){return a&&b&&a.title===b.title&&a.body===b.body}
function noteButtons(){const u=el('noteUndoBtn'),r=el('noteRedoBtn');if(u)u.disabled=!notePast.length;if(r)r.disabled=!noteFuture.length;mcnUpdateButtons()}
function beginNoteHistory(id){noteHistoryId=id;notePast=[];noteFuture=[];noteCurrent=noteState();noteButtons()}
function captureNoteChange(){const next=noteState();if(!next)return;if(!noteCurrent){noteCurrent=next;return}if(!noteEqual(next,noteCurrent)){notePast.push(noteCurrent);if(notePast.length>250)notePast.shift();noteFuture=[];noteCurrent=next}noteButtons()}
function beforeNoteAction(){if(!noteCurrent)noteCurrent=noteState();else captureNoteChange()}
function afterNoteAction(){captureNoteChange()}
function applyNoteState(state){
 const title=el('ctitle'),body=el('cbody');if(!title||!body)return;
 title.value=state.title;body.innerHTML=mcnSanitize(state.body);
 const focus=el(state.focus)||body;focus.focus();
 if(focus===body)mcnPlaceCursor(body,state.start);else if(Number.isInteger(state.start))focus.setSelectionRange(Math.min(state.start,focus.value.length),Math.min(state.end,focus.value.length));
 noteCurrent=noteState();noteButtons();
}
function noteUndo(){captureNoteChange();if(!notePast.length)return;const previous=notePast.pop();noteFuture.push(noteCurrent);applyNoteState(previous)}
function noteRedo(){captureNoteChange();if(!noteFuture.length)return;const next=noteFuture.pop();notePast.push(noteCurrent);applyNoteState(next)}
document.addEventListener('input',e=>{if(editing&&(e.target?.id==='ctitle'||e.target?.id==='cbody'))captureNoteChange()});
function insertList(kind){const area=el('cbody');if(!area)return;beforeNoteAction();mcnRestoreSelection();area.focus();document.execCommand(kind==='bullet'?'insertUnorderedList':'insertOrderedList',false);afterNoteAction()}
function cardHtml(c,section){const isEditing=editing===c.id;return `<article class="card" id="${escapeHtml(c.id)}"><div class="cardHead"><h3>${escapeHtml(c.title)}</h3><div class="cardActions"><button class="small" data-mcn-click="editCard('${c.id}')">✎ Edit</button></div></div>${isEditing?`<div class="editPanel"><label><span style="position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0">Note name</span><input class="editTitle" id="ctitle" placeholder="Note name" value="${escapeHtml(draftNoteId===c.id?'':c.title)}"></label><label>Information<div class="editBody richEditor" id="cbody" role="textbox" aria-label="Information" aria-multiline="true" contenteditable="true" spellcheck="true">${mcnEditorHtml(c.body)}</div></label><div class="formatBar" role="toolbar" aria-label="Note formatting">
<button type="button" class="fmtBtn" id="noteUndoBtn" data-mcn-click="noteUndo()" title="Undo" aria-label="Undo" disabled>↶</button>
<button type="button" class="fmtBtn" id="noteRedoBtn" data-mcn-click="noteRedo()" title="Redo" aria-label="Redo" disabled>↷</button>
<button type="button" class="fmtBtn" title="Add icon" aria-label="Add icon" data-mcn-mousedown="event.preventDefault()" data-mcn-click="openIconPicker('note')">😊</button>
<button type="button" class="fmtBtn fmtNumber" title="Numbered list" aria-label="Numbered list" data-mcn-mousedown="event.preventDefault()" data-mcn-click="insertList('number')">1<small>2</small><small>3</small></button>
<button type="button" class="fmtBtn" title="Bullet points" aria-label="Bullet points" data-mcn-mousedown="event.preventDefault()" data-mcn-click="insertList('bullet')">☷</button>
<button type="button" class="fmtBtn fmtWeight" id="mcnBoldBtn" title="Bold" aria-label="Bold" aria-pressed="false" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnApplyFormat('bold')"><b>B</b></button>
<button type="button" class="fmtBtn fmtItalic" id="mcnItalicBtn" title="Italic" aria-label="Italic" aria-pressed="false" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnApplyFormat('italic')"><i>I</i></button>
<div class="mcnColors"><button type="button" class="fmtBtn fmtColor" id="mcnFontColorBtn" title="Font colour" aria-label="Font colour" aria-haspopup="true" aria-expanded="false" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnTogglePalette()"><span>A</span></button>
<div class="mcnColorPalette hidden" id="mcnColorPalette" role="group" aria-label="Font colours">
<button type="button" title="Dark red" aria-label="Dark red" style="--swatch:#84242d" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnSetColor('#84242d')"></button>
<button type="button" title="Dark blue" aria-label="Dark blue" style="--swatch:#214776" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnSetColor('#214776')"></button>
<button type="button" title="Dark green" aria-label="Dark green" style="--swatch:#21643b" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnSetColor('#21643b')"></button>
<button type="button" title="Dark yellow" aria-label="Dark yellow" style="--swatch:#816400" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnSetColor('#816400')"></button>
<button type="button" title="Dark orange" aria-label="Dark orange" style="--swatch:#9a4800" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnSetColor('#9a4800')"></button>
<button type="button" title="Dark purple" aria-label="Dark purple" style="--swatch:#60367b" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnSetColor('#60367b')"></button>
<button type="button" title="Black" aria-label="Black" style="--swatch:#202020" data-mcn-mousedown="event.preventDefault()" data-mcn-click="mcnSetColor('#202020')"></button>
</div></div>
</div><div class="editRow">${draftNoteId===c.id?'':`<button type="button" class="btn tabEditorDelete noteEditorDelete" data-mcn-click="deleteCard('${section.id}','${c.id}')">🗑 Delete Note</button>`}<button type="button" class="btn" data-mcn-click="cancelNoteEdit('${section.id}','${c.id}')">Cancel</button><button type="button" class="btn primary" data-mcn-click="saveCard('${section.id}','${c.id}')">Save Changes</button></div></div>`:`<div class="cardBody">${renderBody(c.body)}</div>`}</article>`}

function render(){
 renderTabs();renderNav();
 const q=searchText.trim().toLocaleLowerCase();
 const tabSections=sections.filter(s=>s.tab===activeTab);
 const displayed=selected==='home'||q?tabSections:tabSections.filter(s=>s.id===selected);
 let count=0,result='';
 if(selected==='home'&&!q){
  if(!tabSections.length){
   const tab=tabs.find(t=>t.id===activeTab);
   result=tab?`<div class="heading"><div><h2>${escapeHtml(tabParts(tab).icon+' '+tabParts(tab).label)}</h2><p class="muted">No notes in this tab yet. Choose Add Note to get started.</p></div>${tabActionsHtml()}</div>`:`<div class="heading"><div><h2 id="guideWelcomeTitle">Welcome to ${escapeHtml(guideName())}</h2><p class="muted">Create a tab, or use Import My Notes to bring in your saved notes.</p><div class="webHomeActions"><button class="btn primary" data-mcn-click="receiveMyNotes()">↙ Import My Notes</button></div></div></div>`;
  }else{
   result=`<div class="heading"><div><h2 id="guideWelcomeTitle">Welcome to ${escapeHtml(guideName())}</h2><p class="muted">Choose a section from the sidebar to view its notes.</p></div></div>`;
  }
 }
 for(const s of displayed){
  const cards=q?s.cards.filter(c=>(s.title+' '+c.title+' '+mcnPlainText(c.body)).toLocaleLowerCase().includes(q)):s.cards;
  if(q&&!cards.length)continue;
  count+=cards.length;
  result+=`<div class="heading"><div><h2><button class="sectionIconButton" title="Change section icon" aria-label="Change icon for ${escapeHtml(s.title)}" data-mcn-click="openIconPicker('section','${s.id}')">${escapeHtml(s.icon||'📁')}</button> <button class="sectionTitleEdit" data-mcn-click="renameSection('${s.id}')" title="Edit section name" aria-label="Edit section name">${escapeHtml(s.title)}</button></h2></div>${tabActionsHtml(s.id)}</div>`;
  if(cards.length)result+=cards.map(c=>cardHtml(c,s)).join('');
  else result+='<div class="empty">No notes yet. Click Add Note to get started.</div>';
 }
 if(selected!=='home'&&!q&&displayed.some(s=>s.id===selected)){
  result+=`<div class="sectionDeleteBottom"><button type="button" class="btn" data-mcn-click="deleteSection('${selected}')" title="Delete this section and its notes">🗑 Delete Section</button></div>`;
 }
 if(q)result=`<div class="heading"><div><h2>Search results</h2><p class="muted">${count} matching notes for “${escapeHtml(searchText)}”</p></div></div>`+(result||'<div class="empty">No matching notes found.</div>');
 el('view').innerHTML=result;
 applyGuideBrand();if(editing)noteButtons();
 if(tourStep>=0)requestAnimationFrame(renderTour);
}
function editCard(id){editing=id;render();el('ctitle')?.focus();beginNoteHistory(id)}
function saveCard(sid,cid){captureNoteChange();const s=sections.find(s=>s.id===sid),c=s?.cards.find(c=>c.id===cid);if(!c)return;const title=el('ctitle').value.trim(),body=mcnNoteBodyForSave(el('cbody'));if(!title){alert('Please enter a heading.');return}c.title=title;c.body=body;editing=null;draftNoteId=null;draftSectionId=null;noteHistoryId=null;notePast=[];noteFuture=[];noteCurrent=null;save();render();toast('Note saved');if(tourStep===4)finishTutorial()}
let draftNoteId=null,draftSectionId=null;
function addCard(sid){
 sid=sid||((selected!=='home'&&sections.some(s=>s.id===selected))?selected:sections.find(s=>s.tab===activeTab)?.id);
 draftSectionId=null;
 if(!sid){
  const newSection={id:'s'+Date.now()+'n'+Math.floor(Math.random()*10000),title:'Notes',icon:'📝',tab:activeTab,cards:[]};
  sections.push(newSection);sid=newSection.id;draftSectionId=sid;
 }
 const s=sections.find(x=>x.id===sid);if(!s)return;
 const c={id:'c'+Date.now()+'x'+Math.floor(Math.random()*1000),title:'New Note',body:''};
 s.cards.unshift(c);draftNoteId=c.id;selected=sid;searchText='';el('search').value='';editing=c.id;
 render();el('ctitle')?.focus();beginNoteHistory(c.id);el('scrollArea').scrollTop=0;nextTourStep(3,4);
}
function cancelNoteEdit(sid,cid){
 if(draftNoteId===cid){
  const s=sections.find(x=>x.id===sid);
  if(s)s.cards=s.cards.filter(c=>c.id!==cid);
  if(s&&draftSectionId===sid&&!s.cards.length){sections=sections.filter(x=>x.id!==sid);selected='home';saveNav()}
 }
 draftNoteId=null;draftSectionId=null;editing=null;noteHistoryId=null;notePast=[];noteFuture=[];noteCurrent=null;
 if(tourStep===4)tourStep=3;
 render();
}
function deleteCard(sid,cid){
 const section=sections.find(s=>s.id===sid),note=section?.cards.find(c=>c.id===cid);
 if(!note)return;
 if(!confirm('Delete the note “'+note.title+'”? This will remove its saved contents. Save a backup first if needed.'))return;
 const remaining=sections.map(s=>s.id===sid?{...s,cards:s.cards.filter(c=>c.id!==cid)}:s);
 try{webGuardSave();localStorage.setItem(KEY,JSON.stringify(remaining))}
 catch(error){alert('Could not delete this note safely: '+error.message);return}
 sections=remaining;editing=null;draftNoteId=null;draftSectionId=null;noteHistoryId=null;notePast=[];noteFuture=[];noteCurrent=null;
 recordHistory();render();toast('Note deleted');
}
function addSection(){const title=prompt('Name of your new section:');if(!title?.trim())return;const s={id:'s'+Date.now(),title:title.trim(),icon:'📁',tab:activeTab,cards:[]};sections.push(s);save();select(s.id);toast('Section created')}
function renameSection(id){const s=sections.find(x=>x.id===id);if(!s)return;const title=prompt('Section name:',s.title);if(!title?.trim())return;s.title=title.trim();save();render()}
function deleteCurrentSection(){if(selected==='home'||!sections.some(s=>s.id===selected)){toast('Choose a section first');return}deleteSection(selected)}
function deleteSection(id){
 const section=sections.find(s=>s.id===id);if(!section)return;
 const count=section.cards.length;
 const question='Delete the section “'+section.title+'” and all its notes?'+
   '\n\n'+count+' '+(count===1?'note':'notes')+' will be deleted. Other sections will stay unchanged.'+
   '\nSave a backup first if you need these notes.';
 if(!confirm(question))return;
 const remaining=sections.filter(s=>s.id!==id);
 try{webGuardSave();localStorage.setItem(KEY,JSON.stringify(remaining))}
 catch(error){alert('Could not delete this section safely: '+error.message);return}
 sections=remaining;recordHistory();
 if(selected===id){selected='home';editing=null;draftNoteId=null;draftSectionId=null;searchText='';el('search').value=''}
 saveNav();render();toast('Section deleted');
}
async function copyNote(sid,cid){const c=sections.find(s=>s.id===sid)?.cards.find(c=>c.id===cid);if(!c)return;try{await navigator.clipboard.writeText(c.title+'\n\n'+mcnPlainText(c.body));toast('Copied')}catch(e){const t=document.createElement('textarea');t.value=c.title+'\n\n'+mcnPlainText(c.body);document.body.append(t);t.select();document.execCommand('copy');t.remove();toast('Copied')}}
function closeSettings(){el('settingsMenu').classList.add('hidden');el('settingsButton').setAttribute('aria-expanded','false')}
function toggleSettings(){const menu=el('settingsMenu');const opening=menu.classList.contains('hidden');menu.classList.toggle('hidden',!opening);el('settingsButton').setAttribute('aria-expanded',String(opening));if(opening){el('guideOwnerName').value=guideOwner;applyGuideBrand();mcnRefreshUpdateDisplay();nextTourStep(0,1)}}
let mcnSettingsSelectionDrag=false;
el('guideOwnerName').addEventListener('pointerdown',()=>{mcnSettingsSelectionDrag=true});
document.addEventListener('pointerup',()=>{if(mcnSettingsSelectionDrag)setTimeout(()=>{mcnSettingsSelectionDrag=false},0)});
document.addEventListener('click',e=>{if(mcnSettingsSelectionDrag)return;if(!el('settingsWrap').contains(e.target))closeSettings()});
el('guideOwnerName').addEventListener('input',function(){const name=this.value.trim().replace(/[’']s$/i,'');el('guideNamePreview').textContent='App name: '+(name?name+"'s Creative Notes":'My Creative Notes')});
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&!e.altKey&&editing&&['ctitle','cbody'].includes(document.activeElement?.id)){const key=e.key.toLowerCase();if(key==='z'||key==='y'){e.preventDefault();if(key==='y'||e.shiftKey)noteRedo();else noteUndo();return}}if(e.key==='Escape'){closeSettings();closeIconPicker();if(!el('tabEditorOverlay').classList.contains('hidden'))closeTabEditor()}});
// Version 23 backups preserve empty tabs, notes and the personalised name.
function exportData(){
 if(webStorageReadError){alert('The stored notes could not be loaded; exporting an empty backup is blocked. Restore a known-good backup first.');return;}
 const payload={format:'MyCreativeGuideBackup',version:2,exportedAt:new Date().toISOString(),
  guideOwner, tabs, sections};
 const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
 const a=document.createElement('a'),url=URL.createObjectURL(blob);
 a.href=url;a.download='MyCreativeGuide-Backup-'+new Date().toISOString().slice(0,10)+'.json';
 document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Backup saved to Downloads');
}
// V6: portable transfer file (not continuous cloud sync). Works with the Android share sheet when supported.
function shareMyNotes(){
 closeSettings();
 if(editing){alert('Save or cancel your note edit before sharing your notes.');return}
 if(webStorageReadError){alert('The stored notes could not be loaded. Sharing is blocked to protect your information.');return}
 const payload={format:'MyCreativeGuideBackup',version:2,exportedAt:new Date().toISOString(),guideOwner,tabs,sections};
 const name='MyCreativeNotes-Transfer-'+new Date().toISOString().slice(0,10)+'.json';
 const file=new File([JSON.stringify(payload,null,2)],name,{type:'application/json'});
 if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){
   navigator.share({files:[file],title:'My Creative Notes',text:'My Creative Notes transfer file. Keep this file private.'})
    .then(()=>toast('Notes shared')).catch(err=>{if(err.name!=='AbortError'){console.warn('Share failed',err);downloadTransferFile(file)}});
 }else downloadTransferFile(file);
}
function downloadTransferFile(file){
 const url=URL.createObjectURL(file),a=document.createElement('a');
 a.href=url;a.download=file.name;document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),15000);
 toast('Notes file saved. Send it to your other device.');
}
function receiveMyNotes(){
 if(editing){alert('Save or cancel your note edit before receiving notes.');return}
 closeSettings();
 document.getElementById('mcnReceiveOverlay').classList.remove('hidden');
 document.getElementById('mcnReceiveMerge').focus();
}
function closeReceiveNotes(){document.getElementById('mcnReceiveOverlay').classList.add('hidden')}
function chooseReceiveMode(mode){closeReceiveNotes();beginBackupImport(mode)}
let mcnPendingImportConfirmation=null;
function mcnAskImportConfirmation(mode){
 return new Promise(resolve=>{
  mcnPendingImportConfirmation=resolve;
  const yes=el('mcnConfirmYes');
  el('mcnConfirmHeading').textContent=mode==='restore'?'Restore My Notes?':'Import My Notes?';
  el('mcnConfirmDesc').textContent=mode==='restore'?'Your current notes will be replaced by the backup.':'Keep your current tabs and add notes from the backup?';
  yes.textContent=mode==='restore'?'Restore':'Import';
  el('mcnConfirmOverlay').classList.remove('hidden');
  yes.focus();
 });
}
function mcnResolveImportConfirmation(approved){
 el('mcnConfirmOverlay').classList.add('hidden');
 const resolve=mcnPendingImportConfirmation;mcnPendingImportConfirmation=null;
 if(resolve)resolve(Boolean(approved));
}
let pendingImportMode=null;
function beginBackupImport(mode){
 if(mode!=='restore'&&mode!=='merge')return;
 pendingImportMode=mode;
 closeSettings();
 const input=el('importFile');input.value='';input.click();
}
let importedIdCounter=0;
function importedId(prefix){return prefix+Date.now().toString(36)+'x'+(++importedIdCounter).toString(36)+'x'+Math.floor(Math.random()*1e6).toString(36)}
function tabNameFromLegacyId(id){
 return ({work:'💼 Work',personal:'🏠 Personal',maori:'🌿 Te Reo Māori',spiritual:'📖 Spiritual',home:'Imported Notes'})[id]||'Imported Tab';
}
// Accept both the old array-only backup and Version 22's complete-backup format.
// Assign safe internal IDs; never execute anything contained in a backup file.
function parseGuideBackup(raw){
 const obj=Array.isArray(raw)?{sections:raw}:raw;
 if(!obj||typeof obj!=='object'||!Array.isArray(obj.sections))throw Error('This is not a My Creative Notes backup.');
 if(obj.tabs!==undefined&&!Array.isArray(obj.tabs))throw Error('The tabs in this backup are invalid.');
 if(obj.sections.length>15000||(obj.tabs||[]).length>3000)throw Error('This backup contains too many items.');
 const incomingTabs=[],incomingSections=[],oldToNew=new Map();
 function registerTab(sourceId,name,icon=null){
  const k=String(sourceId);
  if(oldToNew.has(k))return oldToNew.get(k);
  const tab={id:importedId('t'),name:name.trim()||'Imported Tab'};
  if(typeof icon==='string'&&icon.trim())tab.icon=icon.slice(0,24);
  incomingTabs.push(tab);oldToNew.set(k,tab.id);return tab.id;
 }
 for(const t of obj.tabs||[]){
  if(!t||typeof t.id!=='string'||typeof t.name!=='string'||!t.name.trim())throw Error('A tab in the backup is invalid.');
  registerTab(t.id,t.name.slice(0,160),t.icon);
 }
 for(const s of obj.sections){
  if(!s||typeof s.title!=='string'||!Array.isArray(s.cards))throw Error('A section in the backup is invalid.');
  if(s.cards.length>25000)throw Error('Too many notes in a section.');
  const oldTab=typeof s.tab==='string'&&s.tab?s.tab:defaultTab(s);
  const tabId=oldToNew.get(oldTab)||registerTab(oldTab,tabNameFromLegacyId(oldTab));
  const cards=[];
  for(const c of s.cards){
   if(!c||typeof c.title!=='string'||typeof c.body!=='string')throw Error('A note in the backup is invalid.');
   cards.push({id:importedId('c'),title:c.title,body:c.body});
  }
  incomingSections.push({id:importedId('s'),title:s.title||'Notes',icon:typeof s.icon==='string'?s.icon.slice(0,12):'📝',tab:tabId,cards});
 }
 const hasOwner=Object.prototype.hasOwnProperty.call(obj,'guideOwner')&&typeof obj.guideOwner==='string';
 return {tabs:incomingTabs,sections:incomingSections,hasOwner,owner:hasOwner?obj.guideOwner.trim().slice(0,16):null};
}
function mergedBackup(backup){
 const resultTabs=tabs.map(t=>({...t}));
 const resultSections=sections.map(s=>({...s,cards:s.cards.map(c=>({...c}))}));
 const tabMap=new Map();let tabsAdded=0,sectionsAdded=0,notesAdded=0,duplicatesSkipped=0;
 for(const t of backup.tabs){
  let dest=resultTabs.find(x=>tabParts(x).label.toLocaleLowerCase()===tabParts(t).label.toLocaleLowerCase());
  if(!dest){dest={id:importedId('t'),name:t.name};if(t.icon)dest.icon=t.icon;resultTabs.push(dest);tabsAdded++}
  tabMap.set(t.id,dest.id);
 }
 for(const section of backup.sections){
  const destinationId=tabMap.get(section.tab);
  if(!destinationId)throw Error('An imported section has no tab.');
  let target=resultSections.find(x=>x.tab===destinationId&&x.title.trim().toLocaleLowerCase()===section.title.trim().toLocaleLowerCase());
  if(!target){target={id:importedId('s'),title:section.title,icon:section.icon,tab:destinationId,cards:[]};resultSections.push(target);sectionsAdded++}
  const existing=new Set(target.cards.map(c=>JSON.stringify([c.title,c.body])));
  for(const card of section.cards){
   const signature=JSON.stringify([card.title,card.body]);
   if(existing.has(signature)){duplicatesSkipped++;continue}
   target.cards.push({id:importedId('c'),title:card.title,body:card.body});
   existing.add(signature);notesAdded++;
  }
 }
 return {tabs:resultTabs,sections:resultSections,tabsAdded,sectionsAdded,notesAdded,duplicatesSkipped};
}
// Write the complete state before updating the screen. If saving fails, restore old stored values.
function applyBackup(nextTabs,nextSections,nextOwner=null,restoreOwner=false){
 const prior=[[KEY,localStorage.getItem(KEY)],[TAB_KEY,localStorage.getItem(TAB_KEY)],[GUIDE_OWNER_KEY,localStorage.getItem(GUIDE_OWNER_KEY)]];
 try{
  localStorage.setItem(KEY,JSON.stringify(nextSections));
  localStorage.setItem(TAB_KEY,JSON.stringify(nextTabs));
  if(restoreOwner){if(nextOwner)localStorage.setItem(GUIDE_OWNER_KEY,nextOwner);else localStorage.removeItem(GUIDE_OWNER_KEY)}
 }catch(error){
  for(const [k,v] of prior){try{if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(_){}}
  throw Error('Could not save the imported information. Your existing notes have been kept. '+error.message);
 }
 if(tourStep>=0)finishTutorial();
 webStorageReadError=false;document.querySelector('.mcnDataWarning')?.remove();
 tabs=nextTabs;sections=nextSections;
 if(restoreOwner)guideOwner=nextOwner||'';
 activeTab=tabs[0]?.id||'home';selected=sections.find(s=>s.tab===activeTab)?.id||'home';
 editing=null;draftNoteId=null;draftSectionId=null;searchText='';el('search').value='';
 recordHistory();render();el('scrollArea').scrollTop=0;
}
el('importFile').addEventListener('change',async function(){
 const file=this.files?.[0],mode=pendingImportMode;
 this.value='';pendingImportMode=null;
 if(!file||!mode)return;
 try{
  if(file.size>20*1024*1024)throw Error('Please choose a backup smaller than 20 MB.');
  const backup=parseGuideBackup(JSON.parse(await file.text()));
  if(mode==='restore'){
   if(!await mcnAskImportConfirmation('restore'))return;
   applyBackup(backup.tabs,backup.sections,backup.owner,backup.hasOwner);
   toast('Notes restored');
  }else{
   const merged=mergedBackup(backup);
   if(!await mcnAskImportConfirmation('merge'))return;
   applyBackup(merged.tabs,merged.sections);
   toast('Imported '+merged.notesAdded+' note(s)');
  }
 }catch(error){alert('Unable to '+(mode==='restore'?'restore':'merge')+' backup: '+error.message)}
});
/* Open the normal browser website. In installed-app windows, Chrome normally routes a target=_blank link to a browser tab. */
/* Switch View: Chrome controls app-link routing and whether a page may close its window. */
function mcnIsInstalledView(){
 return matchMedia('(display-mode: standalone)').matches||matchMedia('(display-mode: minimal-ui)').matches||navigator.standalone===true;
}
function mcnShowSwitchInstructions(message){
 const guide=el('mcnAppAccessGuide');
 guide.textContent=message;
 guide.classList.remove('hidden');
 el('mcnAppAccessButton').setAttribute('aria-expanded','true');
}
async function mcnSwitchView(){
 if(editing){alert('Please save or cancel the note you are editing before switching views.');return}
 const guide=el('mcnAppAccessGuide');
 guide.classList.add('hidden');
 el('mcnAppAccessButton').setAttribute('aria-expanded','false');
 const url='https://brokaz-app-hub.github.io/creative-notes/';
 if(mcnIsInstalledView()){
  if(!confirm('Switch to Browser?\n\nOpen Creative Notes in a Chrome tab.'))return;
  // A link to the same app scope may be routed back into the installed app by Chrome.
  // Never claim this has definitely opened a normal tab.
  const next=window.open(url,'_blank','noopener,noreferrer');
  if(!next)mcnShowSwitchInstructions('Chrome may block or redirect this link. To open a normal browser tab, use the app window’s ⋮ menu and choose Open in Chrome.');
  else mcnShowSwitchInstructions('Chrome may open another app window instead of a tab. If that happens, use the app window’s ⋮ menu and select Open in Chrome. You can close this window once your other view is ready.');
  return;
 }
 if(mcnDeferredInstallPrompt){
  if(!confirm('Install Creative Notes?\n\nOpen your notes in a separate app window.'))return;
  const prompt=mcnDeferredInstallPrompt;
  mcnDeferredInstallPrompt=null;
  try{
   await prompt.prompt();
   const answer=await prompt.userChoice;
   if(answer?.outcome==='accepted'){toast('Creative Notes installed. Open it using your app shortcut.');return}
  }catch(error){console.warn('Install prompt:',error)}
  mcnShowSwitchInstructions('Installation was not completed. You can try your browser’s Install app or Add to Home Screen option.');
  return;
 }
 // Browsers do not reliably disclose whether this site was previously installed.
 if(!confirm('Switch to Creative Notes App?\n\nTry to open Creative Notes in the installed app?'))return;
 mcnShowSwitchInstructions('If Creative Notes is installed, open it using its taskbar, Dock, or Home Screen shortcut. If it is not installed, use your browser’s Install app or Add to Home Screen option. Websites cannot reliably launch an existing installed app.');
}
/* App Access: browser-managed shortcuts, shown for the user's device. */
function mcnAppAccessDevice(){
 const ua=navigator.userAgent||'';
 if(/iPad|iPhone|iPod/.test(ua)||(/Macintosh/.test(ua)&&navigator.maxTouchPoints>1))return 'ios';
 if(/Android/i.test(ua))return 'android';
 if(/Windows/i.test(ua))return 'windows';
 if(/Macintosh|Mac OS X/i.test(ua))return 'mac';
 return /Mobi/i.test(ua)?'mobile':'desktop';
}
function mcnAppAccessSetup(){
 const kind=mcnAppAccessDevice(),mobile=kind==='ios'||kind==='android'||kind==='mobile';
 el('mcnAppAccessLabel').textContent='Switch View';
 el('mcnAppAccessIcon').textContent='🔄';
 const guide=el('mcnAppAccessGuide');
 if(kind==='ios')guide.innerHTML='<strong>Add to Home Screen (iPhone/iPad)</strong><ol><li>Open My Creative Notes in <strong>Safari</strong>.</li><li>Tap the <strong>Share</strong> button (square with an upward arrow).</li><li>Choose <strong>Add to Home Screen</strong>, then tap <strong>Add</strong>.</li></ol>';
 else if(kind==='android')guide.innerHTML='<strong>Add to Home Screen (Android)</strong><ol><li>Open My Creative Notes in <strong>Chrome</strong>.</li><li>Tap the <strong>⋮</strong> menu.</li><li>Choose <strong>Add to Home screen</strong> or <strong>Install app</strong>, then confirm.</li></ol>';
 else if(kind==='mac')guide.innerHTML='<strong>Add to Dock (Mac)</strong><ol><li>In <strong>Safari</strong>, open the <strong>File</strong> menu and select <strong>Add to Dock</strong>, then confirm.</li><li>In <strong>Chrome</strong>, use the <strong>⋮</strong> menu to install the page as an app if offered. Open the app and choose <strong>Options → Keep in Dock</strong> from its Dock icon.</li></ol>';
 else if(kind==='windows')guide.innerHTML='<strong>Pin to Taskbar (Windows)</strong><ol><li>In <strong>Chrome</strong>, open the <strong>⋮</strong> menu and look for <strong>Cast, save and share → Install page as app</strong>. In <strong>Edge</strong>, use <strong>⋯ → Apps → Install this site as an app</strong>.</li><li>Confirm the installation if your browser offers it.</li><li>Right-click its taskbar icon and select <strong>Pin to taskbar</strong>. If needed, find the app in Windows Start first.</li></ol><p>Browser menu wording may vary. If installation is unavailable, use the browser’s Create shortcut option, then pin its Windows shortcut.</p>';
 else guide.innerHTML='<strong>App shortcut</strong><p>On a phone, open this page in Safari (iPhone) or Chrome (Android), then use the browser menu to add it to the Home Screen. On a Windows PC, install the page as an app from Chrome or Edge, then pin it to the taskbar.</p>';
}
let mcnDeferredInstallPrompt=null;
window.addEventListener('beforeinstallprompt',event=>{
 event.preventDefault();
 mcnDeferredInstallPrompt=event;
});
window.addEventListener('appinstalled',()=>{
 mcnDeferredInstallPrompt=null;
 const guide=el('mcnAppAccessGuide');
 guide.classList.add('hidden');
 el('mcnAppAccessButton').setAttribute('aria-expanded','false');
});
mcnAppAccessSetup();
if('serviceWorker' in navigator && location.protocol==='https:'){
 window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(e=>console.warn('App service worker:',e)));
}
/* v3: Manual website update checks ONLY. No startup, hourly or visibility checks. */
const MCN_WEB_VERSION='8.0.34';
let mcnUpdateState={type:'idle',latest:null,lastChecked:0,checking:false};
function mcnVersionCompare(a,b){
 const read=v=>{const m=String(v??'').trim().replace(/^v/i,'').match(/^(\d+)(?:\.(\d+))?(?:\.(\d+))?$/);return m?[+m[1],+(m[2]||0),+(m[3]||0)]:null};
 const x=read(a),y=read(b);if(!x||!y)return null;
 for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i]?1:-1;
 return 0;
}
function mcnUpdateFeedUrl(){
 // Published webpage only: read the version file beside the webpage.
 // For local previews, fetch the published update feed only when explicitly clicked.
 if(location.protocol==='file:')return 'https://brokaz-app-hub.github.io/creative-notes/my-creative-notes-updates.json';
 return new URL('my-creative-notes-updates.json',location.href).href;
}
function mcnSafeHttpsUrl(raw,base){
 try{const u=new URL(String(raw||''),base);if(u.protocol==='https:'||(u.protocol==='http:'&&['127.0.0.1','localhost'].includes(u.hostname)))return u.href}catch(e){}
 return null;
}
function mcnRefreshUpdateDisplay(){
 const btn=el('mcnUpdateButton'),status=el('mcnUpdateStatus');if(!btn||!status)return;
 btn.classList.remove('isAvailable','isCurrent');
 if(mcnUpdateState.type==='available')btn.classList.add('isAvailable');
 if(mcnUpdateState.type==='current')btn.classList.add('isCurrent');
 btn.disabled=mcnUpdateState.checking;
 btn.textContent='Update';
 status.className='mcnUpdateStatus';
 if(mcnUpdateState.checking){status.textContent='Checking your website…';return}
 switch(mcnUpdateState.type){
 case 'available': status.textContent='New version '+mcnUpdateState.latest.version+' available. Click Update to choose whether to get it.';break;
 case 'current': status.textContent='You are up to date (checked '+new Date(mcnUpdateState.lastChecked).toLocaleTimeString()+').';status.classList.add('isCurrent');break;
 case 'unconfigured':status.textContent='Website not connected. Enter your website update-file address once below.';break;
 case 'error':status.textContent='Could not reach your website update file. Please try again later.';status.classList.add('isError');break;
 default: status.textContent='Click Update to manually check your website.';
 }
}
async function mcnCheckForUpdates(){
 if(mcnUpdateState.checking)return;
 mcnUpdateState.checking=true;mcnRefreshUpdateDisplay();
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),10000);
 try{
  // The public site can briefly lag behind the repository following a release.
  // Check both version files on an explicit user click; use the newest valid result.
  const published=mcnUpdateFeedUrl();
  const source='https://raw.githubusercontent.com/BroKaz-App-Hub/BroKaz-App-Hub.github.io/main/creative-notes/my-creative-notes-updates.json';
  const addresses=[published,source].map(url=>mcnSafeHttpsUrl(url,location.href)).filter(Boolean);
  const results=await Promise.allSettled(addresses.map(async address=>{
   const url=new URL(address);url.searchParams.set('_check',String(Date.now()));
   const response=await fetch(url.href,{cache:'no-store',credentials:'omit',signal:controller.signal});
   if(!response.ok)throw Error('HTTP '+response.status);
   const info=await response.json();
   if(!info||info.app!=='my-creative-notes-web'||typeof info.version!=='string'||mcnVersionCompare(info.version,MCN_WEB_VERSION)===null)throw Error('Invalid update feed');
   const appUrl=mcnSafeHttpsUrl(info.url,address);
   if(!appUrl)throw Error('Invalid update URL');
   return {version:info.version,url:appUrl,notes:typeof info.notes==='string'?info.notes.slice(0,300):''};
  }));
  const valid=results.filter(r=>r.status==='fulfilled').map(r=>r.value).sort((a,b)=>mcnVersionCompare(b.version,a.version));
  if(!valid.length)throw Error('Both update feeds unavailable');
  const latest=valid[0],comparison=mcnVersionCompare(latest.version,MCN_WEB_VERSION);
  mcnUpdateState={type:comparison>0?'available':'current',latest:comparison>0?latest:null,lastChecked:Date.now(),checking:false};
 }catch(error){
  console.warn('Creative Notes update check:',error);
  mcnUpdateState={type:'error',latest:null,lastChecked:Date.now(),checking:false};
 }finally{clearTimeout(timeout);mcnRefreshUpdateDisplay()}
}
function mcnUpdateButtonClick(){
 if(mcnUpdateState.checking)return;
 if(mcnUpdateState.type==='available'&&mcnUpdateState.latest){mcnShowUpdateDialog();return}
 mcnCheckForUpdates();
}
function mcnShowUpdateDialog(){
 if(mcnUpdateState.type!=='available'||!mcnUpdateState.latest)return;
 closeSettings();el('mcnUpdateOverlay').classList.remove('hidden');el('mcnOpenUpdateButton').focus();
}
function mcnHideUpdateDialog(){el('mcnUpdateOverlay').classList.add('hidden')}
async function mcnOpenNewVersion(){
 if(!mcnUpdateState.latest)return;
 if(editing){alert('Save or cancel your note edit before opening an update.');return}
 const {version}=mcnUpdateState.latest;
 const url=new URL(mcnUpdateState.latest.url,window.location.href);
 if(url.origin!==location.origin){alert('Update address does not match this app website.');return}
 const btn=el('mcnOpenUpdateButton');
 btn.disabled=true;btn.textContent='Loading update…';
 try{
  // GitHub Pages may not have deployed the release yet even when the feed has updated.
  // Confirm the page itself contains the expected release before leaving this window.
  const check=new URL(url.href);check.searchParams.set('mcn_preflight',String(Date.now()));
  const response=await fetch(check.href,{cache:'no-store'});
  if(!response.ok)throw Error('Website returned '+response.status);
  const html=await response.text();
  const detected=html.match(/const MCN_WEB_VERSION='(\d+\.\d+\.\d+)'/);
  if(!detected||mcnVersionCompare(detected[1],version)<0){
   alert('The new version has been announced, but the website is still publishing it. Please try Get update again in a minute.');
   return;
  }
  url.searchParams.set('mcn_version',version);
  url.searchParams.set('mcn_refresh',String(Date.now()));
  window.location.replace(url.href);
 }catch(error){
  console.warn('Could not load published update:',error);
  alert('Could not verify the updated website. Please check your connection and try again.');
 }finally{btn.disabled=false;btn.textContent='Get update ↗'}
}
function mcnVerifyLoadedUpdate(){
 const params=new URLSearchParams(location.search),expected=params.get('mcn_version');
 if(!expected||mcnVersionCompare(expected,MCN_WEB_VERSION)!==1)return;
 const key='mcn_update_retry_'+expected;
 let attempts=0;
 try{attempts=Number(sessionStorage.getItem(key)||'0')}catch(e){}
 if(attempts<2){
  try{sessionStorage.setItem(key,String(attempts+1))}catch(e){}
  const url=new URL(location.href);url.searchParams.set('mcn_refresh',String(Date.now()));
  window.location.replace(url.href);
 }else{
  setTimeout(()=>alert('The updated page has not finished publishing. This window is still running Web v'+MCN_WEB_VERSION+'. Please try Update again shortly.'),400);
 }
}
mcnVerifyLoadedUpdate();
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(!el('mcnUpdateOverlay').classList.contains('hidden'))mcnHideUpdateDialog();if(!el('mcnReceiveOverlay').classList.contains('hidden'))closeReceiveNotes()}});

// Don't overwrite shared notes merely because another window opens.
recordHistory();el('search').addEventListener('input',function(){searchText=this.value;editing=null;render();el('scrollArea').scrollTop=0});render();
mcnRefreshUpdateDisplay();
try{if(localStorage.getItem(TOUR_KEY)!=='completed')startTutorial()}catch(e){startTutorial()}
