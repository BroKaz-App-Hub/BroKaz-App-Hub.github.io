"use strict";
const MCN_EVENT_ACTIONS={toggleSidebar,showHome,toggleSettings,saveGuideName,chooseMcnTheme,mcnUpdateButtonClick,mcnSwitchView,shareMyNotes,receiveMyNotes,startTutorial,chooseReceiveMode,closeReceiveNotes,mcnResolveImportConfirmation,mcnHideUpdateDialog,exportData,mcnOpenNewVersion,closeTabEditor,saveTabEditor,deleteTabFromEditor,closeIconPicker,renderIconChoices,finishTutorial,switchTab,renameTab,startTabDrag,tabDragOver,tabDragLeave,dropOnTab,finishDrag,addTab,chooseTabEditorIcon,startSectionDrag,sectionDragOver,sectionDragLeave,dropOnSection,moveSectionWithKeyboard,clickSidebar,chooseIcon,editCard,noteUndo,noteRedo,openIconPicker,insertList,mcnApplyFormat,mcnTogglePalette,mcnSetColor,deleteCard,cancelNoteEdit,saveCard,renameSection,deleteSection,addCard};
function mcnDispatch(code,event,element){
 if(!code)return;
 if(code.startsWith("if(event.target===this)")) {
  if(event.target!==element)return;
  code=code.slice("if(event.target===this)".length);
 }
 for(const part of code.split(";")){
  const statement=part.trim();
  if(!statement)continue;
  if(statement==="return false"||statement==="event.preventDefault()"){event.preventDefault();continue;}
  const match=/^([A-Za-z_$][\w$]*)\((.*)\)$/.exec(statement);
  if(!match||!Object.prototype.hasOwnProperty.call(MCN_EVENT_ACTIONS,match[1])){console.error("Unsupported control:",statement);continue;}
  const raw=match[2].trim();
  const parts=raw?raw.match(/'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|[^,]+/g):[];
  if(!parts)throw Error("Invalid control arguments: "+raw);
  const args=parts.map(x=>{
   x=x.trim();
   if(x==="event")return event;
   if(x==="this")return element;
   if(x==="true")return true;
   if(x==="false")return false;
   if(/^[-+]?\d+(?:\.\d+)?$/.test(x))return Number(x);
   if((x.startsWith("'")&&x.endsWith("'"))||(x.startsWith('"')&&x.endsWith('"')))return x.slice(1,-1).replace(/\\(['"\\])/g,"$1");
   throw Error("Unsupported argument: "+x);
  });
  MCN_EVENT_ACTIONS[match[1]](...args);
 }
}
for(const type of ["click","dblclick","submit","input","change","dragstart","dragover","dragleave","drop","dragend","keydown","mousedown"]){
 document.addEventListener(type,event=>{
  const attr="data-mcn-"+type,node=event.target.closest?.("["+attr+"]");
  if(node){if(type==="submit")event.preventDefault();mcnDispatch(node.getAttribute(attr),event,node)}
 },true);
}
